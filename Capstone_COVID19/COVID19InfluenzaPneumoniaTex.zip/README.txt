Readme for PPS Authoring Template
=================================

The first release CUP-JNL-PPS.cls (version 0.1) and latex template
includes following files: (The current release is version 0.1)

********************************** Files **********************************

README.txt               - This file.

CUP-JNL-PPS.cls 	 - The CUP Authoring template class file.

Sample.pdf               - A sample output of Authoring template.

Sample.tex               - The main file of latex template.

Fig.eps                  - A sample image.

orcid_logo.eps		 - ORCID logo 
***************************************************************************
